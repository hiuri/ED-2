#include<stdio.h>
#include<stdlib.h>
#include "suffix.h"



Suffix* create_suffix(String *s, int index){
    Suffix* suf = malloc(sizeof *s);
    suf->s = s; //cortar o sufixo aqui!!!!!!!!!
    suf->index = index;
    return suf;
}

//Libera a memoria ocupada pelo sufixo
void destroy_suffix(Suffix *suf){
    free(suf);//Completar essa funcao
}