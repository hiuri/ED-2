#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "str.h"
#include "suffix.h"

int main(){
	FILE *arq;
	FILE *s;
	arq = fopen("abra.txt", "rt"); //Abertura do arquivo
	if(arq == NULL){
		printf("falha na abertura do arquivo");
	}
	
	long int i=0,j, result;
	long int N;
	result = fscanf(arq,"%ld", &N);//leitura do numero de caracteres
	char texto[N], char_aux;
	int cont_espaco = 0;
	result = fscanf(arq, "%c", &char_aux); //Consumindo o primeiro '\n' 
	while (!feof(arq))
    {
	// Leitura ja retirando os espacos excessivos e as quebras de linha
		result = fscanf(arq, "%c", &char_aux);  // lendo caracter a caractere
		if(char_aux != '\n'){
			if(char_aux != ' '){
				texto[i] = char_aux;
				i++;
				cont_espaco = 0;
			}else if(cont_espaco == 0){
				texto[i] = ' ';
				i++;
				cont_espaco = 1;
			}
		}else if(cont_espaco == 0){
			texto[i] = ' ';
			i++;
			cont_espaco = 1;
		}
	}
	texto[i] = '\n'; //fim da String de entrada
	fclose(arq); //terminada a leitura do arquivo de entrada

	//LOGICA PRINCIPAL
	String* string = create_string(texto); //Criando a Struct String gigante
	Suffix** array = create_suf_array(string,i);//i guarda o tamanho da string sem os espacos e quebras
	//imprime(array,i);

	//NAO CONSEGUI USAR A QSORT!!!

	//qsort(array,i,sizeof(struct Suffix*),compare_suffix);
	booble_sort(array, i);

	char querry[4] = "AB";
	//printf("%d\n\n",(int)strlen(querry));
	int achou;
	int k;
	for(k=0; k<strlen(querry);k++){
		k=k;
	}

	achou = buscabinaria(i, array, querry,k);

	printf("%d", achou);

	imprime(array,i); //Impressao em arquivo
	destroy_string(string);
	destroy_suf_array(array,i);
	return 0;
}
