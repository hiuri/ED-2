//Trab HIURI & LEONAM

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "biblioteca.h"


//Funcao principal com a manipulacao dos arquivos de entrada
int main(int argc, char *argv[ ]){
	FILE *arq;
	arq =fopen(argv[3], "rt");//Abertura do arquivo
	if( arq==NULL){
		printf("Falha na leitura do arquivo");
	}
	//leitura dos dados
	int result, aux,tamanho_vet,cont;
	int top = atoi(argv[2]); //quantidade de elementos a serem exibidos no final
	aux = fscanf(arq, "%d",&tamanho_vet);//leitura da quantidade de entradas
	int vet[tamanho_vet];
	for(cont=0;cont<tamanho_vet;cont++){//Preenchimento do vetor
		result = fscanf(arq, "%d", &aux);
		vet[cont]=aux;
	}

	int tamanho = strlen(argv[1]);
	int i;
	char *string = argv[1];
	for (i=0;i<tamanho;i++){//acoes passadas na entrada
		switch (string[i])
		{
   			case 'a':
     			quick_sort(vet,0,tamanho_vet-1);
				shell_sort(vet, tamanho_vet-1);
				heap_sort(vet,tamanho_vet);
				selection_sort(vet, tamanho_vet);
				insertion_sort(vet, tamanho_vet);
   				break;

   			case 's':
     			selection_sort(vet, tamanho_vet);
   				break;
			case 'i':
				insertion_sort(vet, tamanho_vet);
				break;
			case 'e':
				shell_sort(vet,tamanho_vet);
				break;
			case 'q':
				quick_sort(vet,0,tamanho_vet-1);
				break;
			case 'h':
				heap_sort(vet,tamanho_vet);
				break;
			case '1'://Impressao dos T maiores valores
				for(i=tamanho_vet-1;i>tamanho_vet-top-1;i--){
					printf("%d\n", vet[i]);
				}

   			default:
     			break;
		};
	}


	fclose(arq);
	return 0; 
}
