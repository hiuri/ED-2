#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

//Declaracao das funcoes
void quick_sort(int *vet, int esquerda, int direita);

void shell_sort(int *vet, int tam);

void heap_sort(int *vet, int tam);

void selection_sort(int *vet, int tam);

void insertion_sort(int *vet, int tam);


#endif //BIBLIOTECA_H
