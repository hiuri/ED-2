#include "biblioteca.h"

//Funcao Quick Sort
void quick_sort(int *vet, int esquerda, int direita) {
    int i, j, x, y;
     
    i = esquerda;
    j = direita;
    x = vet[(esquerda + direita) / 2];
     
    while(i <= j) {
        while(vet[i] < x && i < direita) {
            i++;
        }
        while(vet[j] > x && j > esquerda) {
            j--;
        }
        if(i <= j) {
            y = vet[i];
            vet[i] = vet[j];
            vet[j] = y;
            i++;
            j--;
        }
    }
    //Chamadas recursivas da funcao ate estar ordenado
    if(j > esquerda) {
        quick_sort(vet, esquerda, j);
    }
    if(i < direita) {
        quick_sort(vet, i, direita);
    }
}

//Funcao Shell Sort
void shell_sort(int *vet, int tam)
{
 int i , j , x;
 int gap = 1;
  
 do {
  gap = 3*gap+1;
 } while(gap < tam);
  
 do {
  gap /= 3;
  for(i = gap; i < tam; i++) {
   x = vet[i];
   j = i - gap;
    
   while (j >= 0 && x < vet[j]) {
    vet[j + gap] = vet[j];
    j -= gap;
   }
   vet[j + gap] = x;
  }
 }while(gap > 1);
}

//Funcao que cria a arvore para a heap_sort
void cria_heap(int *vet, int ini, int fim){
	int aux = vet[ini], i = ini*2+1;
	while(i<=fim){
		if(i < fim){
			if(vet[i] < vet[i + 1]){
				i++;
			}	
		}
		if(aux < vet[i]){
			vet[ini] = vet[i];
			ini = i;
			i = 2* ini + 1;
		}else{
			i = fim + 1;
		}
		
	}
	vet[ini] = aux;
}

//Funcao Heap Sort
void heap_sort(int *vet, int tam){
	int i, aux, meio_vet=(tam-1)/2;
	for(i=meio_vet; i>=0; i--){
		cria_heap(vet,i,tam-1);
	}
	for(i = tam-1; i >=1; i--){
		aux = vet[0];
		vet[0] = vet[i];
		vet[i] = aux;
		cria_heap(vet, 0, i-1);
	}
}

//Funcao selection_sort
void selection_sort(int *vet, int tam) { 
  int i, j, min, aux;
  for (i = 0; i < (tam-1); i++) 
  {
     min = i;
     for (j = (i+1); j < tam; j++) {
       if(vet[j] < vet[min]) 
         min = j;
     }
     if (i != min) {
       aux = vet[i];
       vet[i] = vet[min];
       vet[min] = aux;
     }
  }
}

//Funcao insertion_sort
void insertion_sort(int *vet, int tam){
    int i, j, aux;
    for (i = 1; i < tam; i++) {
        aux = vet[i];
        j = i - 1;
        while (j >= 0 && vet[j] > aux) {
            vet[j + 1] = vet[j];
            j = j - 1;
        }
        vet[j + 1] = aux;
    }
}

